# Language: Polish (MAZOVIA)
# Translated by Mateusz Viste
# Polish letters encoded in the MAZOVIA standard
#
# prompts and error messages
1.1:Niepoprawna liczba parametr�w
1.2:Niepoprawna data
1.3:Niepoprawny parametr
1.4:�cie�ka �r�d�owa jest za d�uga
1.5:Niepoprawne okre�lenie dysku �r�d�owego
1.6:Nie odnaleziono �cie�ki �r�d�owej
1.7:�cie�ka �r�d�owa jest za d�uga
1.8:�cie�ka docelowa jest za d�uga
1.9:Niepoprawne okre�lenie dysku docelowego
1.10:Czy
1.11:okre�la nazw� pliku
1.12:czy nazw� katalogu u celu
1.13:Plik
1.14:Katalog
1.15:�cie�ka docelowa jest za d�uga
1.16:Nie mo�na przeprowadzi� cyklicznego kopiowania
1.17:Wci�nij enter by kontynuowa�...
1.18:Pliku nie odnaleziono

# the help message
2.1:Kopiuje pliki i drzewo katalog�w.
2.2:XCOPY �r�d�o [cel] [/parametry]
2.3:  �r�d�o       Okre�la katalog i/lub nazw� pliku(�w) do skopwiowania.
2.4:  cel          Okre�la miejsce docelowe i/lub nazw� nowych plik�w.
2.5:  /A           Kopiuje tylko pliki z atrybutem archiwalnym i nie zmienia
2.6:               tego atrybutu.
2.7:  /C           Kontynuuje kopiowanie, nawet je�li wyst�pi� b��dy.
2.8:  /D[:M/D/R]   Kopiuje pliki zmienione po lub w podanej dacie. Je�li �adnej daty
2.9:               nie podano, skopiowane b�d� tylko pliki nowsze od swoich
2.10:               istniej�cych docelowych odpowiednik�w.
2.11:  /E           Kopiuje wszystkie katalogi, nawet je�li s� puste.
2.12:  /F           Wy�wietla pe�ne nazwy plik�w �r�d�owych i docelowych.
2.13:  /H           Kopiuje zar�wno pliki ukryte i systemowe jak i niezabezpieczone.
2.14:  /I           Je�li cel nie istnieje, a kopiowanych jest wi�cej ni� jeden
2.15:               plik, program traktuje cel jako katalog.
2.16:  /L           Wy�wietla nazwy plik�w nie kopiuj�c ich. (symulacja kopiowania)
2.17:  /M           Kopiuje tylko pliki z atrybutem archiwalnym, a po skopiowaniu
2.18:               znosi atrybut archiwalny z plik�w �r�d�owych.
2.19:  /N           Nie pyta o potwierdzenie nadpisania plik�w docelowych tylko
2.20:               automatycznie je pomija.
2.21:  /P           Pyta o potwierdzenie przed stworzeniem ka�dego docelowego pliku.
2.22:  /Q           Tryb dyskretny, nie wy�wietla nazw kopiowanych plik�w.
2.23:  /R           Nadpisuje tak�e pliki z atrybutem "tylko do odczytu".
2.24:  /S           Kopiuje katalogi i podkatalogi, za wyj�tkiem pustych.
2.25:  /T           Tworzy drzewo katalog�w bez kopiowania plik�w. Puste katalogi
2.26:               nie s� kopiowane. By je skopiowa� u�yj parametru /E.
2.27:  /V           Sprawdza ka�dy nowy plik.
2.28:  /W           Czeka na wci�ni�cie klawisza przed rozpocz�ciem kopiowania.
2.29:  /Y           Nie pyta czy nadpisa� ju� istniej�ce docelowe pliki, tylko
2.30:               automatycznie je nadpisuje.
2.31:  /-Y          Wymusza pytanie o potwierdzenie nadpisania ju� istniej�cych
2.32:               docelowych plik�w.
2.33:Parametry /Y i /N mog� by� ustawione domy�lne w zmiennej �rodowiskowej COPYCMD.
2.34:Mo�na je potem uniewa�ni� u�ywaj�c /-Y z linii polece�.
2.35:wci�nij enter po wi�cej

# more messages
1.19:plik(i) skopiowane
1.20:Nie mo�na stworzy� katalogu
1.21:Plik nie mo�e skopiowa� si� sam na siebie
1.22:Odczyt niedozwolony
1.23:Niewystarczaj�ca ilo�� miejsca na dysku katalogu docelowego
1.24:Zapis niedozwolony
1.25:Niewystarczaj�ca ilo�� miejsca na dysku katalogu docelowego
1.26:Kopiowanie

# the following three are used in shared.inc:
25.0:Nie mo�na otworzy� pliku �r�d�owego
25.1:Nie mo�na stworzy� katalogu
25.2:B��d zapisu u celu

# more confirmation messages, must start upper case,
# 3.2 to 3.5 must all start different:
3.1:Zamie�
3.2:Tak
3.3:Nie
3.4:Zamie� wszystkie
3.5:Pomi� wszystkie
