# Translated by Matej Horvat (http://matejhorvat.si/), last update 2013-11-30

# prompts and error messages
1.1:Neveljavno �tevilo parametrov
1.2:Neveljaven datum
1.3:Neveljavna mo�nost
1.4:Pot izvora predolga
1.5:Neveljavna specifikacija izvornega pogona
1.6:Poti izvora ni mogo�e najti
1.7:Pot izvora predolga
1.8:Pot cilja predolga
1.9:Neveljavna specifikacija ciljnega pogona
1.10:Ali je
1.11:ime datoteke ali
1.12:imenika na cilju
1.13:Datoteka
1.14:Imenik
1.15:Ciljna pot predolga
1.16:Ni mogo�e kopirati imeni�kega drevesa vase
1.17:Pritisnite Enter za nadaljevanje
1.18:Datoteke ni mogo�e najti

# the help message
2.1:Kopira datoteke in imeni�ka drevesa.
2.2:XCOPY izvor [cilj] [mo�nosti]
2.3:  izvor       Dolo�i imenik in/ali ime datotek za kopiranje.
2.4:  cilj        Dolo�i lokacijo in/ali ime novih datotek.
2.5:  /A          Kopira samo datoteke z atributom "za arhiviranje" in ga ne
2.6:              spreminja.
2.7:  /C          Nadaljuje s kopiranjem tudi v primeru napak.
2.8:  /D[:M/D/Y]  Kopira samo datoteke, ki so bile spremenjene dolo�enega dne ali
2.9:              po njem. �e ni dolo�en noben datum, bodo kopirane samo
2.10:              datoteke, ki so novej�e od obstoje�ih na cilju.
2.11:  /E          Kopira morebitne podimenike, tudi �e so prazni.
2.12:  /F          Prikazuje polna imena izvornih in ciljnih datotek.
2.13:  /H          Kopira tudi skrite in sistemske datoteke.
2.14:  /I          �e cilj ne obstaja in se kopira ve� kot ena datoteka,
2.15:              predpostavi, da je cilj imenik.
2.16:  /L          Simulira kopiranje; na�teva datoteke, ne da bi jih kopiral.
2.17:  /M          Kopira samo datoteke z atributom "za arhiviranje" in ga
2.18:              izklju�i po kopiranju.
2.19:  /N          Ne spra�uje, ali �elite zamenjati obstoje�e datoteke, in te
2.20:              datoteke presko�i.
2.21:  /P          Vpra�a za dovoljenje, preden ustvari vsako ciljno datoteko.
2.22:  /Q          Tihi na�in; ne prikazuje imen kopiranih datotek.
2.23:  /R          Zamenja tudi morebitne datoteke, ki so samo za branje.
2.24:  /S          Kopira imenike in podimenike, razen tistih, ki so prazni.
2.25:  /T          Ustvari imeni�ko drevo, ne da bi kopiral datoteke. Prazni
2.26:              imeniki ne bodo kopirani - za to je treba dodati mo�nost /E.
2.27:  /V          Preveri vsako novo datoteko.
2.28:  /W          Pred kopiranjem po�aka na pritisk tipke.
2.29:  /Y          Ne spra�uje, ali �elite zamenjati obstoje�e datoteke, in te
2.30:              datoteke vedno zamenja z novimi.
2.31:  /-Y         Vedno spra�uje, ali �elite zamenjati obstoje�e datoteke z
2.32:              novimi.
2.33:Mo�nost /Y ali /N je lahko prednastavljena v okoljski spremenljivki COPYCMD.
2.34:Obe mo�nosti lahko onemogo�ite z mo�nostjo /-Y na ukazni vrstici.
2.35:Pritisnite Enter za ve�

# more messages
1.19:datotek kopiranih
1.20:Ni mogo�e ustvariti imenika
1.21:Datoteke ni mogo�e kopirati nase
1.22:Dostop za branje zavrnjen
1.23:Ni dovolj prostora na ciljnem disku
1.24:Dostop za pisanje zavrnjen
1.25:Ni dovolj prostora na ciljnem disku
1.26:Kopiram

# the following three are used in shared.inc:
25.0:Ni mogo�e odpreti izvorne datoteke
25.1:Ni mogo�e ustvariti cilja
25.2:Napaka pri pisanju na cilj

# more confirmation messages, must start upper case,
# 3.2 to 3.5 must all start different:
3.1:Zamenjam
3.2:Da
3.3:Ne
3.4:Zamenjaj vse
3.5:Presko�i vse
